import { FolderOpen, Save, Trash2 } from 'lucide-react';
import type { AssignableUser, Project, ProjectPayload } from '../../../../shared/types';
import { Button } from '../../../../shared/ui';
import { ProjectForm } from '../../../components/project-form/ProjectForm';

export function ProjectInfoPanel({ project, draft, users, saving, onDraftChange, onSave, onDelete }: {
  project: Project; draft: ProjectPayload; users: AssignableUser[]; saving: boolean;
  onDraftChange: (value: ProjectPayload) => void; onSave: () => void; onDelete: () => void;
}) {
  return <aside className="manager-panel project-info-panel project-info-reference">
    <div className="reference-card-head"><div className="reference-step-title"><span className="project-card-icon-reference"><FolderOpen size={18} /></span><div><b>اطلاعات پروژه</b><span>ویرایش و ذخیره مشخصات پروژه</span></div></div></div>
    <ProjectForm value={draft} onChange={onDraftChange} readOnly={!project.can_edit} canManageAssignments={project.can_manage_assignments} assignableUsers={users} />
    {project.can_edit ? <div className="project-edit-actions project-edit-actions-reference">
      <Button variant="primary" loading={saving} leadingIcon={<Save size={15} />} onClick={onSave}>ذخیره اطلاعات</Button>
      {project.can_delete && <Button variant="danger" disabled={saving} leadingIcon={<Trash2 size={15} />} onClick={onDelete}>حذف پروژه</Button>}
    </div> : <div className="readonly-project-note">این پروژه با دسترسی مشاهده باز شده است و قابل ویرایش یا اجرا نیست.</div>}
  </aside>;
}
