import { AppTopNav } from '../../../shared/components';
import { Button, ConfirmDialog } from '../../../shared/ui';
import { ProjectMessage } from '../../components/ProjectMessage';
import { ProjectDataPanel } from './_components/ProjectDataPanel';
import { ProjectInfoPanel } from './_components/ProjectInfoPanel';
import { ProjectWorkflowsPanel } from './_components/ProjectWorkflowsPanel';
import { useProjectDetailController } from './_hooks/useProjectDetailController';
import type { Project, UserProfile } from '../../../shared/types';

export type ProjectDetailPageProps = { user: UserProfile; project: Project; onBack: () => void; onOpenEditor: (workflowId: number | null) => void; onProjectUpdated: (project: Project) => void; onProfile: () => void; onAdmin: () => void; onLogout: () => void };

export function ProjectDetailPage(props: ProjectDetailPageProps) {
  const c = useProjectDetailController(props);
  return <div className="app-shell manager-shell">
    <AppTopNav user={props.user} title={props.project.name} subtitle="جزئیات پروژه، داده‌ها و جریان‌های ذخیره‌شده" onBack={props.onBack} onProfile={props.onProfile} onAdmin={props.onAdmin} onLogout={props.onLogout} />
    <main className="manager-page project-detail-reference-page iota-minimal-page">
      <ProjectMessage message={c.message} />
      <div className="reference-back-row"><Button onClick={props.onBack}>بازگشت به پروژه‌ها</Button></div>
      <section className="project-detail-reference-layout">
        <ProjectInfoPanel project={props.project} draft={c.draft} users={c.users} saving={c.saving} onDraftChange={c.setDraft} onSave={c.save} onDelete={() => c.setDeleteOpen(true)} />
        <section className="detail-main-stack detail-main-stack-reference"><ProjectDataPanel datasets={c.datasets} usage={c.artifactUsage} canEdit={props.project.can_edit} onUpload={c.uploadDataset} onDelete={c.deleteDataset} /><ProjectWorkflowsPanel project={props.project} workflows={c.workflows} manager={c.workflow} onOpenEditor={props.onOpenEditor} /></section>
      </section>
    </main>
    <ConfirmDialog open={c.deleteOpen} title="حذف پروژه" message="این پروژه حذف شود؟ این کار قابل بازگشت نیست." confirmLabel="حذف پروژه" danger busy={c.saving} onClose={() => c.setDeleteOpen(false)} onConfirm={c.remove} />
    <ConfirmDialog open={Boolean(c.workflow.deleteTarget)} title="حذف جریان" message={c.workflow.deleteTarget ? `جریان «${c.workflow.deleteTarget.name}» حذف شود؟ تاریخچه اجراهای قبلی پروژه حفظ می‌شود.` : ''} confirmLabel="حذف جریان" danger busy={c.workflow.actionId === c.workflow.deleteTarget?.id} onClose={() => c.workflow.setDeleteTarget(null)} onConfirm={c.workflow.remove} />
  </div>;
}
