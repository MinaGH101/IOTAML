import { useState, type FormEvent } from 'react';
import { CheckCircle2, Eye, EyeOff, Lock, RefreshCw, User } from 'lucide-react';
import { authApi } from '../../_service/authApi';
import { setAuthToken } from '../../../shared/_service/httpClient';
import { ThemeToggle } from '../../../shared/_components/ThemeToggle';
import DotGrid from './_components/DotGrid';
import type { UserProfile } from '../../../shared/_types';

export function LoginPage({ onLogin }: { onLogin: (user: UserProfile) => void }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setMessage('');

    try {
      const result = await authApi.login({ username, password });
      setAuthToken(result.access_token);
      onLogin(result.user);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'ورود ناموفق بود');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-page login-page">
      <div className="login-grid-background" aria-hidden="true">
        <DotGrid
          dotSize={2}
          gap={10}
          baseColor="#2F293A"
          activeColor="#5227FF"
          proximity={120}
          shockRadius={450}
          shockStrength={5}
          resistance={750}
          returnDuration={1.5}
        />
      </div>

      <div className="login-grid-overlay" aria-hidden="true" />

      <div className="auth-theme-control">
        <ThemeToggle />
      </div>

      <main className="login-shell">
        <div className="login-card">
          <form className="login-form" onSubmit={submit}>
            <header className="login-header">
              <div className="login-brand">
                <img src="/iota.png" alt="IOTA" />
              </div>
              <h1>ورود به پلتفرم</h1>
            </header>

            <label>
              ایمیل یا نام کاربری
              <div className="auth-input-wrap">
                <User size={16} />
                <input
                  value={username}
                  onChange={(event) => setUsername(event.target.value)}
                  autoComplete="username"
                  placeholder="name@example.com"
                />
              </div>
            </label>

            <label>
              رمز عبور
              <div className="auth-input-wrap">
                <Lock size={16} />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  className="auth-eye-button"
                  onClick={() => setShowPassword((value) => !value)}
                  aria-label={showPassword ? 'پنهان کردن رمز عبور' : 'نمایش رمز عبور'}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </label>

            {message && <div className="auth-error">{message}</div>}

            <button className="primary auth-submit" disabled={busy} type="submit">
              {busy ? <RefreshCw size={16} className="spin" /> : <CheckCircle2 size={16} />}
              ورود
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
