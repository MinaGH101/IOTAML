import type { Edge, Node } from '@xyflow/react';
import type { AnalysisBoardItem, AnalysisBoardTab, BoardViewport } from './board';
import type { Output } from './output';
import type { RegistryNode } from '../../shared/types';
import { resolveRegistryId, type LegacyNodeAliases } from './catalog';
import { parseColumnParam } from './columnContext';
import { createOutputSnapshot } from './outputSnapshot';
import { restoreOutputReference } from '../../features/results/model/outputReference';
export { connectedGraph } from './executionGraph';
export { inputColumnContextForNode, inputColumnsForNode } from './columnContext';
export type FlowGraph = {
    nodes: Node[];
    edges: Edge[];
    meta?: {
        datasetId?: number | null;
        targetColumn?: string;
        taskType?: string;
        workflowViewport?: WorkflowViewport;
        analysisBoard?: AnalysisBoardItem[];
        analysisBoards?: AnalysisBoardTab[];
        activeAnalysisBoardId?: string;
    };
};
export type WorkflowViewport = {
    x: number;
    y: number;
    zoom: number;
};
export function restoreWorkflowViewport(value: unknown): WorkflowViewport {
    const viewport = value && typeof value === 'object' && !Array.isArray(value)
        ? value as Partial<WorkflowViewport>
        : {};
    const x = Number(viewport.x);
    const y = Number(viewport.y);
    const zoom = Number(viewport.zoom);
    return {
        x: Number.isFinite(x) ? x : 0,
        y: Number.isFinite(y) ? y : 0,
        zoom: Number.isFinite(zoom) ? Math.min(2, Math.max(0.1, zoom)) : 1,
    };
}
const SECTION_TITLES = new Set([
    'Data Input', 'Data Inspection', 'Data Cleaning', 'Anomaly Detection',
    'Transformation', 'Visualizations', 'ML Data Processing',
    'ML Model Design and Training', 'ML Model Analysis', 'Export or Report',
    'Utilities / Advanced', 'ورود داده', 'تبدیل داده', 'تحلیل و نمودار',
    'آموزش مدل', 'تحلیل مدل',
]);
function paramsFromRegistry(node: RegistryNode) {
    const schema = node.settingsSchema?.length ? node.settingsSchema : node.params || [];
    return Object.fromEntries(schema.map((param) => [param.name, param.default]));
}
function normalizedStoredParams(registryId: string, value: unknown) {
    const params = value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};
    if (registryId === 'TR-014') {
        return {
            id_column: params.id_column ?? params.index_column ?? null,
            first_column_name: params.first_column_name ?? params.output_label_column ?? 'variable',
        };
    }
    if (registryId === 'VZ-005') {
        const selectedRows = parseColumnParam(params.selected_rows);
        const oldColor = String(params.color || '').trim();
        const currentColors = params.series_colors && typeof params.series_colors === 'object' && !Array.isArray(params.series_colors)
            ? params.series_colors as Record<string, unknown>
            : {};
        return {
            x_columns: parseColumnParam(params.x_columns),
            selected_rows: selectedRows,
            series_colors: Object.keys(currentColors).length ? currentColors : Object.fromEntries(selectedRows.map((row) => [row, oldColor]).filter(([, color]) => Boolean(color))),
            orientation: params.orientation ?? 'vertical',
            guideline_values: params.guideline_values ?? '',
            guideline_labels: params.guideline_labels ?? '',
        };
    }
    return params;
}
export function makeNode(registryNode: RegistryNode, index: number, position?: {
    x: number;
    y: number;
}): Node {
    return {
        id: `${registryNode.id}-${Date.now()}-${Math.random().toString(16).slice(2)}`,
        type: 'mlNode',
        position: position ?? { x: 120 + (index % 4) * 260, y: 100 + Math.floor(index / 4) * 180 },
        data: {
            registryId: registryNode.id,
            catalogId: registryNode.id,
            typeLabel: registryNode.label,
            label: `Node ${index + 1}`,
            category: registryNode.category,
            description: registryNode.description,
            inputs: registryNode.inputs || [],
            outputs: registryNode.outputs || [],
            executionMode: registryNode.executionMode,
            comingSoon: registryNode.comingSoon,
            params: paramsFromRegistry(registryNode),
            componentSnapshot: registryNode.template?.componentSnapshot,
            isComponent: registryNode.isComponent || false,
            componentId: registryNode.componentId,
            componentVersionId: registryNode.componentVersionId,
            componentVersion: registryNode.componentVersion,
        },
    };
}
export function normalizeFlowNodes(items: Node[], registry: RegistryNode[], aliases: LegacyNodeAliases): Node[] {
    const byId = Object.fromEntries(registry.map((item) => [item.id, item]));
    return items.map((node, index) => {
        const storedRegistryId = String(node.data?.registryId || node.data?.catalogId || '');
        const canonicalId = resolveRegistryId(storedRegistryId, aliases);
        const registryNode = byId[canonicalId];
        const storedTypeLabel = String(node.data?.typeLabel || '').trim();
        const typeLabel = !storedTypeLabel || SECTION_TITLES.has(storedTypeLabel)
            ? String(registryNode?.label || node.data?.label || 'Node Type')
            : storedTypeLabel;
        const currentLabel = String(node.data?.label || '').trim();
        const label = !currentLabel || currentLabel === typeLabel || SECTION_TITLES.has(currentLabel)
            ? `Node ${index + 1}`
            : currentLabel;
        return {
            ...node,
            data: {
                ...node.data,
                registryId: canonicalId,
                catalogId: canonicalId,
                typeLabel,
                label,
                category: registryNode?.category || node.data?.category,
                description: registryNode?.description || node.data?.description,
                inputs: registryNode?.inputs || node.data?.inputs || [],
                outputs: registryNode?.outputs || node.data?.outputs || [],
                executionMode: registryNode?.executionMode || node.data?.executionMode || 'instant',
                comingSoon: registryNode?.comingSoon ?? node.data?.comingSoon ?? false,
                params: normalizedStoredParams(canonicalId, node.data?.params),
            },
        };
    });
}
export function normalizeEdgeHandles(nodes: Node[], edges: Edge[]): Edge[] {
    const byId = new Map(nodes.map((node) => [node.id, node]));
    return edges.map((edge) => {
        const sourceNode = byId.get(edge.source);
        const targetNode = byId.get(edge.target);
        const sourcePorts = Array.isArray(sourceNode?.data?.outputs) ? sourceNode.data.outputs as Array<{
            id?: unknown;
        }> : [];
        const targetPorts = Array.isArray(targetNode?.data?.inputs) ? targetNode.data.inputs as Array<{
            id?: unknown;
        }> : [];
        const sourceHandle = String(edge.sourceHandle || sourcePorts[0]?.id || 'output');
        const targetHandle = String(edge.targetHandle || targetPorts[0]?.id || 'input');
        if (edge.sourceHandle === sourceHandle && edge.targetHandle === targetHandle)
            return edge;
        return { ...edge, sourceHandle, targetHandle };
    });
}
export function defaultGraph(registry: RegistryNode[], aliases: LegacyNodeAliases): FlowGraph {
    const byId = Object.fromEntries(registry.map((item) => [item.id, item]));
    const ids = ['DI-002', 'IN-004', 'CL-007', 'VZ-002'];
    const positions = [{ x: 90, y: 230 }, { x: 350, y: 230 }, { x: 610, y: 230 }, { x: 870, y: 230 }];
    const nodes = ids.filter((id) => byId[id]).map((id, index) => {
        const node = makeNode(byId[id], index, positions[index]);
        node.id = `${id}-${index}`;
        if (id === 'DI-002') {
            node.data = { ...node.data, params: { ...(node.data.params as Record<string, unknown>), dataset_id: null } };
        }
        return node;
    });
    const edges: Edge[] = [];
    for (let index = 0; index < nodes.length - 1; index += 1) {
        edges.push({ id: `e${index}`, source: nodes[index].id, target: nodes[index + 1].id, animated: true });
    }
    const normalizedNodes = normalizeFlowNodes(nodes, registry, aliases);
    return {
        nodes: normalizedNodes,
        edges: normalizeEdgeHandles(normalizedNodes, edges),
        meta: { targetColumn: 'target', taskType: 'auto', datasetId: null },
    };
}
export function isTextInput(target: EventTarget | null): boolean {
    return target instanceof HTMLInputElement
        || target instanceof HTMLTextAreaElement
        || target instanceof HTMLSelectElement;
}
export function restoreAnalysisBoardItems(value: unknown): AnalysisBoardItem[] {
    if (!Array.isArray(value))
        return [];
    return value
        .filter((item): item is Partial<AnalysisBoardItem> => Boolean(item && typeof item === 'object' && !Array.isArray(item)))
        .map((item, index) => ({
        id: String(item.id || `board-${Date.now()}-${index}`),
        nodeId: item.nodeId ? String(item.nodeId) : null,
        outputKey: item.outputKey ? String(item.outputKey) : undefined,
        outputIndex: Number(item.outputIndex || 0),
        outputTitle: String(item.outputTitle || `خروجی ${index + 1}`),
        outputKind: String(item.outputKind || 'json'),
        sourceLabel: item.sourceLabel ? String(item.sourceLabel) : undefined,
        x: Number.isFinite(Number(item.x)) ? Number(item.x) : 32 + index * 28,
        y: Number.isFinite(Number(item.y)) ? Number(item.y) : 32 + index * 28,
        w: Number.isFinite(Number(item.w)) ? Number(item.w) : 430,
        h: Number.isFinite(Number(item.h)) ? Number(item.h) : 320,
        runId: item.runId === undefined ? null : Number(item.runId) || null,
        outputRef: restoreOutputReference(item.outputRef),
        snapshot: restoreOutputReference(item.outputRef) ? undefined : createOutputSnapshot(item.snapshot),
        createdAt: String(item.createdAt || new Date().toISOString()),
    }));
}
export function serializeAnalysisBoardItems(items: AnalysisBoardItem[]) {
    return items.map((item) => {
        const { snapshot, ...persistent } = item;
        return {
            ...persistent,
            // Keep a bounded legacy snapshot only until the item is migrated to an output reference.
            ...(item.outputRef ? {} : { snapshot: createOutputSnapshot(snapshot) }),
        };
    });
}
export const MAIN_ANALYSIS_BOARD_ID = 'analysis-board-main';
export function createMainAnalysisBoard(items: AnalysisBoardItem[] = []): AnalysisBoardTab {
    return {
        id: MAIN_ANALYSIS_BOARD_ID,
        name: 'برد اصلی',
        items,
        viewport: { x: 0, y: 0, scale: 1 },
        createdAt: new Date().toISOString(),
    };
}
function restoreBoardViewport(value: unknown): BoardViewport {
    const item = value && typeof value === 'object' && !Array.isArray(value) ? value as Partial<BoardViewport> : {};
    const x = Number(item.x);
    const y = Number(item.y);
    const scale = Number(item.scale);
    return {
        x: Number.isFinite(x) ? x : 0,
        y: Number.isFinite(y) ? y : 0,
        scale: Number.isFinite(scale) ? Math.min(2.25, Math.max(0.35, scale)) : 1,
    };
}
export function restoreAnalysisBoardTabs(value: unknown, legacyItems?: unknown): AnalysisBoardTab[] {
    if (!Array.isArray(value) || value.length === 0) {
        return [createMainAnalysisBoard(restoreAnalysisBoardItems(legacyItems))];
    }
    const tabs = value
        .filter((item): item is Partial<AnalysisBoardTab> => Boolean(item && typeof item === 'object' && !Array.isArray(item)))
        .map((item, index) => ({
        id: String(item.id || (index === 0 ? MAIN_ANALYSIS_BOARD_ID : `analysis-board-${Date.now()}-${index}`)),
        name: String(item.name || (index === 0 ? 'برد اصلی' : `برد ${index + 1}`)).trim() || `برد ${index + 1}`,
        items: restoreAnalysisBoardItems(item.items),
        viewport: restoreBoardViewport(item.viewport),
        createdAt: String(item.createdAt || new Date().toISOString()),
    }));
    const mainIndex = tabs.findIndex((tab) => tab.id === MAIN_ANALYSIS_BOARD_ID);
    if (mainIndex < 0)
        tabs.unshift(createMainAnalysisBoard());
    else if (mainIndex > 0)
        tabs.unshift(tabs.splice(mainIndex, 1)[0]);
    return tabs;
}
export function serializeAnalysisBoardTabs(tabs: AnalysisBoardTab[]) {
    return tabs.map((tab) => ({
        id: tab.id,
        name: tab.name,
        items: serializeAnalysisBoardItems(tab.items),
        viewport: restoreBoardViewport(tab.viewport),
        createdAt: tab.createdAt,
    }));
}
export function workflowOutputSignature(nodes: Node[], edges: Edge[], datasetId: number | null, targetColumn: string, taskType: string) {
    return JSON.stringify({
        nodes: nodes.map((node) => ({
            id: node.id,
            registryId: node.data?.registryId,
            catalogId: node.data?.catalogId,
            params: node.data?.params,
        })),
        edges: edges.map((edge) => ({
            id: edge.id,
            source: edge.source,
            target: edge.target,
            sourceHandle: edge.sourceHandle,
            targetHandle: edge.targetHandle,
        })),
        datasetId,
        targetColumn,
        taskType,
    });
}
